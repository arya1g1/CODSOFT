# 🍽️ Restaurant Menu UI/UX Project

This is a simple, clean, and categorized **restaurant menu design** created with HTML and CSS. The goal is to provide a **visually appealing** and **easy-to-use** menu interface for customers.

## 🎯 Key Features
- Clean layout with categories: Starters, Mains, Desserts, Drinks
- Simple, responsive design using only HTML & CSS
- Easily customizable colors and fonts
- Great for UI/UX portfolios

## 📁 Folder Structure
```
restaurant-menu-uiux/
├── index.html
├── style.css
├── README.md
└── assets/
```

## 🚀 Demo
Add your demo link here (e.g., GitHub Pages, Netlify)

## 🧑‍🎨 Designed By
Arya Gawande
